// BMtoCh10.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

//#include "pch.h"
#include <cstdio>
#include <cassert>
#include <ctime>
#include <string>       // std::string
#include <iostream>     // std::cout
#include <sstream>      // std::stringstream
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "config.h"
#include "i106_stdint.h"
#include "irig106ch10.h"

#include "i106_time.h"
#include "i106_decode_time.h"
#include "i106_decode_1553f1.h"
#include "i106_decode_tmats.h"

using namespace Irig106;

/*
 * Macros and definitions
 * ----------------------
 */

#define MAJOR_VERSION  "01"
#define MINOR_VERSION  "00"

#if !defined(__GNUC__)
#define M_PI        3.14159265358979323846
#define M_PI_2      1.57079632679489661923
#define M_PI_4      0.785398163397448309616
#endif

#define DEG_TO_RAD(angle)     ((angle)*M_PI/180.0)
#define RAD_TO_DEG(angle)     ((angle)*180.0/M_PI)
#define FT_TO_METERS(ft)      ((ft)*0.3048)
#define METERS_TO_FT(meters)  ((meters)/0.3048)
#define SQUARED(value)        ((value)*(value))
#define CUBED(value)          ((value)*(value)*(value))

/*
 * Data structures
 * ---------------
 */

#pragma pack(1)

typedef struct 
    {
    uint16_t    uWordCnt    : 5;    /* Data Word Count or Mode Code      */
    uint16_t    uSubAddr    : 5;    /* Subaddress Specifier              */
    uint16_t    bTR         : 1;    /* Transmit/Receive Flag             */
    uint16_t    uRTAddr     : 5;    /* RT Address                        */
    } SuCmd1553;

// Bluemax XLS data fields
typedef struct
    {
    float   fACTIME;    //  1
    float   fACXF;      //  2
    float   fACYF;      //  3
    float   fACZF;      //  4
    float   fPTCHD;     //  5
    float   fROLLD;     //  6
    float   fHDNGD;     //  7
    float   fGAMAD;     //  8
    float   fAOAD;      //  9
    float   fACLATD;    // 10
    float   fACLOND;    // 11
    float   fACZTRN;    // 12
    float   fACAGLF;    // 13
    float   fACVX;      // 14 (feet/sec)
    float   fACVY;      // 15 (feet/sec)
    float   fACVZ;      // 16 (feet/sec)
    float   fPTCHRT;    // 17
    float   fROLLRT;    // 18
    float   fTURNRT;    // 19
    float   fADGFAC;    // 20
    float   fACTHRO;    // 21
    float   fACVFPS;    // 22
    float   fACSPBK;    // 23
    float   fACFLAP;    // 24
    float   fACWFRT;    // 25
    float   fACAU;      // 26
    float   fACAV;      // 27
    float   fACAW;      // 28
    float   fACAX;      // 29
    float   fACAY;      // 30
    float   fACAZ;      // 31
    float   fADGAMA;    // 32
    float   fACACEL;    // 33
    float   fACGWLB;    // 34
    float   fAIOWE;     // 35
    float   fACEXWT;    // 36
    float   fACWFWT;    // 37
    float   fACFNLB;    // 38
    float   fACLIFT;    // 39
    float   fACDRAG;    // 40
    float   fACFRTN;    // 41
    float   fACCLFT;    // 42
    float   fACCDRG;    // 43
    float   fACGFAC;    // 44
    float   fACEXPS;    // 45
    float   fACDNPR;    // 46
    float   fACMACH;    // 47
    float   fACKTAS;    // 48
    float   fACKCAS;    // 49
    float   fACFNMX;    // 50
    float   fAXPTMN;    // 51
    float   fAXPTMX;    // 52
    float   fAXRLMX;    // 53
    float   fACCLMX;    // 54
    float   fAXGFMX;    // 55
    float   fAOAMXD;    // 56
    float   fACVSND;    // 57
    float   fAXMNMX;    // 58
    float   fAXGFMN;    // 59
    float   fAXGRMX;    // 60
    } SuBluemaxXls;

// F-16/C-130/A-10 EGI
typedef struct INS_DataS {
  uint16_t  uStatus;            //  1
  uint16_t  uTimeTag;           //  2
   int16_t  sVelX_MSW;          //  3
  uint16_t  uVelX_LSW;          //  4
   int16_t  sVelY_MSW;          //  5
  uint16_t  uVelY_LSW;          //  6
   int16_t  sVelZ_MSW;          //  7
  uint16_t  uVelZ_LSW;          //  8
  uint16_t  uAz;                //  9
   int16_t  sRoll;              // 10
   int16_t  sPitch;             // 11
  uint16_t  uTrueHeading;       // 12
  uint16_t  uMagHeading;        // 13
   int16_t        :  5;         // 14
   int16_t  sAccX : 11;         // 14
   int16_t        :  5;         // 15
   int16_t  sAccY : 11;         // 15
   int16_t        :  5;         // 16
   int16_t  sAccZ : 11;         // 16
   int16_t  sCXX_MSW;           // 17
  uint16_t  uCXX_LSW;           // 18
   int16_t  sCXY_MSW;           // 19
  uint16_t  uCXY_LSW;           // 20
   int16_t  sCXZ_MSW;           // 21
  uint16_t  uCXZ_LSW;           // 22
   int16_t  sLon_MSW;           // 23
  uint16_t  uLon_LSW;           // 24
   int16_t  sAlt;               // 25
   int16_t  sSteeringError;     // 26
   int16_t  sTiltX;             // 27
   int16_t  sTiltY;             // 28
   int16_t  sJustInCase[4];     // 29-32
  } SuINS_Data;

// Time write buffer info
typedef struct
    {
    SuI106Ch10Header        suCh10Header;
    struct
        {
        SuTimeF1_ChanSpec   suTimeF1CSDW;
        SuTime_MsgDmyFmt    suTimeDataBuff;
        unsigned char       abyFillChksum[8];   // Just for safety
        } suTimePktBuffer;
    } SuWritePktTimeF1;

// 1553 write buffer info
typedef struct
    {
    SuI106Ch10Header        suCh10Header;
    Su1553F1_ChanSpec     * psu1553CSDW;
    unsigned char         * pchDataBuff;    // Make this char * makes point math easier
    uint32_t                uBuffLen;       // Size of the write buffer
    } SuWriteMsg1553;

/*
 * Module data
 * -----------
 */


/*
 * Function prototypes
 * -------------------
 */

void SimClockToRel(int iI106Handle, double dSimTime, uint8_t abyRelTime[]);
void WriteTmats(int iI106Handle, double fCurrSimClockTime);
void WritePktTimeF1Init(SuWritePktTimeF1 * psuWritePktTimeF1, uint16_t uChID);
void WritePktTimeF1(int iI106Handle, SuWritePktTimeF1 * psuWritePktTimeF1, double fCurrSimClockTime);
void MakeInsNav(SuBluemaxXls * psuBluemaxXls, SuINS_Data * psuInsData);
void WriteMsg1553Init(SuWriteMsg1553 * psuWriteMsg1553, uint16_t uChID);
void WriteMsg1553Append(SuWriteMsg1553 * psuWriteMsg1553, Su1553F1_Header * psu1553IPH, 
        int32_t iCmdWord1, int32_t iStatWord1, int32_t iCmdWord2, int32_t iStatWord2,
        uint16_t auData[]);
void WriteMsg1553Commit(int iI106Handle, SuWriteMsg1553 * psuWriteMsg1553);
//uint32_t I106_CALL_DECL mkgmtime(struct tm * psuTmTime);
void vUsage(void);

// ============================================================================

int main(int iArgc, char * aszArgv[])
{
    char                szInFile[256];     // Input file name
    char                szOutFile[256];    // Output file name
    FILE              * hBMInput;
    bool                bDone;
    char                szLine[1000];
    SuBluemaxXls        suBluemaxXls;

    int                 iI106Handle;
    SuIrig106Time       suIrigTime;
    uint8_t             aubyRelTime[6];
    int64_t             llRelTime;
    SuINS_Data          suInsData;
    SuWritePktTimeF1    suWritePktTimeF1;
    SuWriteMsg1553      suWriteMsg1553;
    Su1553F1_Header     su1553IPH_Nav_25Hz;
    SuCmdWordU          su1553CmdWord1_Nav_25Hz;
    SuCmdWordU          su1553CmdWord2_Nav_25Hz;
    SuStatWordU         su1553StatWord1_Nav_25Hz;
    SuStatWordU         su1553StatWord2_Nav_25Hz;
    Su1553F1_Header     su1553IPH_Nav_1Hz;
    SuCmdWordU          su1553CmdWord1_Nav_1Hz;
    SuStatWordU         su1553StatWord1_Nav_1Hz;

    unsigned long       ulBuffSize = 0L;
    unsigned char     * pvBuff  = NULL;

    EnI106Status        enStatus;
//  Irig106::SuTmatsInfo         suTmatsInfo;

    // Various simulation clocks and time
    uint64_t        ulSimClockTicks;        // Simulation time (ticks)
    uint64_t        ulClockTicks_1S;        // 1 second clock tick counter
    uint64_t        ulClockTicks_100ms;     // 100 millisecond clock tick counter

    double          fSimElapsedTime;        // Simulation elapsed time (seconds)
    double          fSecondsPerTick;        // Seconds per tick
    double          fBluemaxTime;           // Bluemax data time (seconds)
    uint64_t        ulStartRTC;             // Relative Time Counter start value
    uint64_t        ulCurrRTC;              // Current Relative Time Counter
    double          fStartSimClockTime;     // Starting simulation Date/Time
    double          fCurrSimClockTime;      // Current simulation Data/Time
    double          fNextPrintTime;         

    // Init some stuff
    szInFile[0]         = '\0';
    szOutFile[0]        = '\0';
    bDone               = false;
    ulSimClockTicks     = 0;
    fSimElapsedTime     = 0.0;
    fSecondsPerTick     = 0.04f;   // 25 msec
    fBluemaxTime        = 0.0;
    ulStartRTC          = 0;
    ulCurrRTC           = 0;
    fStartSimClockTime  = double(time(NULL));

    // Process command line
    // --------------------

  for (int iArgIdx=1; iArgIdx<iArgc; iArgIdx++) {

    switch (aszArgv[iArgIdx][0]) {

      case '-' :
        switch (aszArgv[iArgIdx][1]) {

          case 'v' :                   // Verbose switch
//            bVerbose = bTRUE;
            break;

          case 't' :                   // Data start date and time
            {
            iArgIdx++;
            struct tm   suStartTime;
            int iArgs = sscanf(aszArgv[iArgIdx],"%d-%d-%d-%d-%d-%d",
                    &suStartTime.tm_mon,  &suStartTime.tm_mday, &suStartTime.tm_year, 
                    &suStartTime.tm_hour, &suStartTime.tm_min,  &suStartTime.tm_sec);
            if (iArgs == 6)
                {
                suStartTime.tm_mon  -= 1;
                suStartTime.tm_year -= 1900;
                fStartSimClockTime = (double)mkgmtime(&suStartTime);
                }
            else
                {
                vUsage();
                return 1;
                }
            }
            break;

          default :
            break;
          } /* end flag switch */
        break;

      default :
        if (szInFile[0] == '\0') strcpy(szInFile, aszArgv[iArgIdx]);
        else                     strcpy(szOutFile,aszArgv[iArgIdx]);
        break;

      } // end command line arg switch
    } // end for all arguments

    if ((strlen(szInFile)==0) || (strlen(szOutFile)==0))
        {
        vUsage();
        return 1;
        }

    // Init some more stuff
    fCurrSimClockTime   = fStartSimClockTime;

    ulClockTicks_1S     = 25;
    ulClockTicks_100ms  =  3;

    suBluemaxXls.fACTIME    = -1.0;
    fNextPrintTime          =  0.0;

    // Setup messages that will be written
    // -----------------------------------

    // Setup 1553 1Hz Nav message fields
    su1553CmdWord1_Nav_1Hz.uValue  = 0x37A0;
    su1553StatWord1_Nav_1Hz.uValue = 0x3000;
    memset(&su1553IPH_Nav_1Hz, 0, sizeof(Su1553F1_Header));
    su1553IPH_Nav_1Hz.uMsgLen   = i1553WordCnt(&(su1553CmdWord1_Nav_1Hz)) * 2 + 4;
    su1553IPH_Nav_1Hz.uGapTime1 = 60;

    // Setup 1553 25Hz Nav message fields
    su1553CmdWord1_Nav_25Hz.uValue  = 0xDB40;
    su1553StatWord1_Nav_25Hz.uValue = 0xD800;
    su1553CmdWord2_Nav_25Hz.uValue  = 0x37A0;
    su1553StatWord2_Nav_25Hz.uValue = 0x3000;
    memset(&su1553IPH_Nav_25Hz, 0, sizeof(Su1553F1_Header));
    su1553IPH_Nav_25Hz.uMsgLen   = i1553WordCnt(&(su1553CmdWord1_Nav_25Hz)) * 2 + 4;
    su1553IPH_Nav_25Hz.bRT2RT    = 1;
    su1553IPH_Nav_25Hz.uGapTime1 = 60;
    su1553IPH_Nav_25Hz.uGapTime2 = 60;

    // Setup 1553 Channel ID 11 channel
    WriteMsg1553Init(&suWriteMsg1553, 11);

    // Open Bluemax XLS file
    hBMInput = fopen(szInFile, "r");
    if (hBMInput == NULL)
        return 1;

    // Get the first header line
    fgets(szLine, sizeof(szLine), hBMInput);

    // Open the output Ch 10 file and init it
    enStatus = enI106Ch10Open(&iI106Handle, szOutFile, I106_OVERWRITE);
    if (enStatus != I106_OK)
        {
        fprintf(stderr, "Error opening data file : Status = %d\n", enStatus);
        return 1;
        }

    // Get time setup
    llRelTime = ulStartRTC;
    vLLInt2TimeArray(&llRelTime, aubyRelTime);
    suIrigTime.enFmt  = I106_DATEFMT_DMY;
    suIrigTime.ulSecs = (unsigned long)fStartSimClockTime;
    suIrigTime.ulFrac = (unsigned long)((fStartSimClockTime - (unsigned long)fStartSimClockTime) * 9999999.9);
    enI106_SetRelTime(iI106Handle, &suIrigTime, aubyRelTime);
    WritePktTimeF1Init(&suWritePktTimeF1, 1);

    // Write initial TMATS and first time packet
    WriteTmats(iI106Handle, fCurrSimClockTime);
    WritePktTimeF1(iI106Handle, &suWritePktTimeF1, fCurrSimClockTime);

    // Start writing
    // -------------

    // Loop until an input is exhausted. Along the way various simulation
    // components check their notion of time against the current simulation
    // time and take appropriate action for this instant of time.
    while (!bDone)
        {
        int iItems;

        // Update input(s)
        // ---------------

        // Bluemax XLS input data
        while (suBluemaxXls.fACTIME < fBluemaxTime)
            {
            // Get the next line        
            fgets(szLine, sizeof(szLine), hBMInput);
            if (feof(hBMInput))
                {
                bDone = true;
                break;
                }
            else
                {
                iItems = sscanf(szLine, " %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f "
                                        " %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f "
                                        " %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f "
                                        " %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f",
                    &suBluemaxXls.fACTIME, &suBluemaxXls.fACXF,   &suBluemaxXls.fACYF,   &suBluemaxXls.fACZF,
                    &suBluemaxXls.fPTCHD,  &suBluemaxXls.fROLLD,  &suBluemaxXls.fHDNGD,  &suBluemaxXls.fGAMAD,
                    &suBluemaxXls.fAOAD,   &suBluemaxXls.fACLATD, &suBluemaxXls.fACLOND, &suBluemaxXls.fACZTRN,
                    &suBluemaxXls.fACAGLF, &suBluemaxXls.fACVX,   &suBluemaxXls.fACVY,   &suBluemaxXls.fACVZ,
                    &suBluemaxXls.fPTCHRT, &suBluemaxXls.fROLLRT, &suBluemaxXls.fTURNRT, &suBluemaxXls.fADGFAC,
                    &suBluemaxXls.fACTHRO, &suBluemaxXls.fACVFPS, &suBluemaxXls.fACSPBK, &suBluemaxXls.fACFLAP,
                    &suBluemaxXls.fACWFRT, &suBluemaxXls.fACAU,   &suBluemaxXls.fACAV,   &suBluemaxXls.fACAW,
                    &suBluemaxXls.fACAX,   &suBluemaxXls.fACAY,   &suBluemaxXls.fACAZ,   &suBluemaxXls.fADGAMA,
                    &suBluemaxXls.fACACEL, &suBluemaxXls.fACGWLB, &suBluemaxXls.fAIOWE,  &suBluemaxXls.fACEXWT,
                    &suBluemaxXls.fACWFWT, &suBluemaxXls.fACFNLB, &suBluemaxXls.fACLIFT, &suBluemaxXls.fACDRAG,
                    &suBluemaxXls.fACFRTN, &suBluemaxXls.fACCLFT, &suBluemaxXls.fACCDRG, &suBluemaxXls.fACGFAC,
                    &suBluemaxXls.fACEXPS, &suBluemaxXls.fACDNPR, &suBluemaxXls.fACMACH, &suBluemaxXls.fACKTAS,
                    &suBluemaxXls.fACKCAS, &suBluemaxXls.fACFNMX, &suBluemaxXls.fAXPTMN, &suBluemaxXls.fAXPTMX,
                    &suBluemaxXls.fAXRLMX, &suBluemaxXls.fACCLMX, &suBluemaxXls.fAXGFMX, &suBluemaxXls.fAOAMXD,
                    &suBluemaxXls.fACVSND, &suBluemaxXls.fAXMNMX, &suBluemaxXls.fAXGFMN, &suBluemaxXls.fAXGRMX);
                assert(iItems == 60);
                }

            // Make BlueMax based nav message(s)
            MakeInsNav(&suBluemaxXls, &suInsData);

            } // end while reading Bluemax XLS data

        // Break out if input is exhausted
        if (bDone)
            break;

        // 25 Hz events
        // ------------
        SimClockToRel(iI106Handle, fCurrSimClockTime, su1553IPH_Nav_25Hz.aubyIntPktTime);
        WriteMsg1553Append(&suWriteMsg1553, &su1553IPH_Nav_25Hz, 
                su1553CmdWord1_Nav_25Hz.uValue, su1553StatWord1_Nav_25Hz.uValue, 
                su1553CmdWord2_Nav_25Hz.uValue, su1553StatWord2_Nav_25Hz.uValue, 
                (uint16_t *)&suInsData);

        // 120 msec events
        // ---------------
        if (ulClockTicks_100ms > 1) ulClockTicks_100ms--;
        else
            {
            WriteMsg1553Commit(iI106Handle, &suWriteMsg1553);
            ulClockTicks_100ms = 3;
            } // end 10 Hz events

        // 1 Hz events
        // -----------
        if (ulClockTicks_1S > 1) ulClockTicks_1S--;
        else
            {
            WritePktTimeF1(iI106Handle, &suWritePktTimeF1, fCurrSimClockTime);
            ulClockTicks_1S = 25;

            SimClockToRel(iI106Handle, fCurrSimClockTime, su1553IPH_Nav_1Hz.aubyIntPktTime);
            WriteMsg1553Append(&suWriteMsg1553, &su1553IPH_Nav_1Hz, 
                    su1553CmdWord1_Nav_1Hz.uValue, su1553StatWord1_Nav_1Hz.uValue, -1, -1,
                    (uint16_t *)&suInsData);
            } // end 1 Hz events

        if (fSimElapsedTime >= fNextPrintTime)
            {
            printf("%f %f %f %f\n", suBluemaxXls.fACTIME, suBluemaxXls.fACLATD, suBluemaxXls.fACLOND, suBluemaxXls.fACKTAS);
//            MakeInsNav(&suBluemaxXls, &suInsData);
            fNextPrintTime += 100.0;
            }

        // Update the various clocks
        ulSimClockTicks++;
        fSimElapsedTime     = ulSimClockTicks * fSecondsPerTick;
        fBluemaxTime        = fSimElapsedTime;
        ulCurrRTC           = ulStartRTC + uint64_t(fSimElapsedTime * 10000000);
        fCurrSimClockTime   = fStartSimClockTime + fSimElapsedTime;
        } // end while reading until done

    fclose(hBMInput);
    enI106Ch10Close(iI106Handle);

    return 0;
}


// ----------------------------------------------------------------------------

void SimClockToRel(int iI106Handle, double dSimTime, uint8_t abyRelTime[])
    {
    SuIrig106Time   suIrigTime;
                        
    suIrigTime.enFmt  = I106_DATEFMT_DMY;
    suIrigTime.ulSecs = (unsigned long)dSimTime;
    suIrigTime.ulFrac = (unsigned long)((dSimTime - (unsigned long)dSimTime) * 9999999.9);
    enI106_Irig2RelTime(iI106Handle, &suIrigTime, abyRelTime);

    return;
    }


// ----------------------------------------------------------------------------

void MakeInsNav(SuBluemaxXls * psuBluemaxXls, SuINS_Data * psuInsData)
    {
    int32_t     lTempVel;
    uint32_t    ulTempLatLon;

    // Zero everthing out
    memset(psuInsData, 0, sizeof(SuINS_Data));

    psuInsData->uStatus      = 0x0020;
    //psuInsData->uTimeTag
    lTempVel = (int32_t)(psuBluemaxXls->fACVX * 0x00040000);
    psuInsData->sVelX_MSW = ( int16_t)((lTempVel >> 16) & 0x0000ffff);
    psuInsData->uVelX_LSW = (uint16_t)((lTempVel      ) & 0x0000ffff);
    lTempVel = (int32_t)(psuBluemaxXls->fACVY * 0x00040000);
    psuInsData->sVelY_MSW = ( int16_t)((lTempVel >> 16) & 0x0000ffff);
    psuInsData->uVelY_LSW = (uint16_t)((lTempVel      ) & 0x0000ffff);
    lTempVel = (int32_t)(psuBluemaxXls->fACVZ * 0x00040000);
    psuInsData->sVelZ_MSW = ( int16_t)((lTempVel >> 16) & 0x0000ffff);
    psuInsData->uVelZ_LSW = (uint16_t)((lTempVel      ) & 0x0000ffff);
    psuInsData->uAz          = (uint16_t)(psuBluemaxXls->fHDNGD / 180.0 * (double)0x7fff);
    psuInsData->sRoll        = ( int16_t)(psuBluemaxXls->fROLLD / 180.0 * (double)0x7fff);
    psuInsData->sPitch       = ( int16_t)(psuBluemaxXls->fPTCHD / 180.0 * (double)0x7fff);
    psuInsData->uTrueHeading = (uint16_t)(psuBluemaxXls->fHDNGD / 180.0 * (double)0x7fff);
    psuInsData->uMagHeading  = (uint16_t)(psuBluemaxXls->fHDNGD / 180.0 * (double)0x7fff);
    psuInsData->sAccX = (int16_t)psuBluemaxXls->fACAU;
    psuInsData->sAccY = (int16_t)psuBluemaxXls->fACAV;
    psuInsData->sAccZ = (int16_t)psuBluemaxXls->fACAW;
    //psuInsData->sCXX_MSW
    //psuInsData->uCXX_LSW
    //psuInsData->sCXY_MSW
    //psuInsData->uCXY_LSW
    ulTempLatLon = (uint32_t)(sin(psuBluemaxXls->fACLATD * M_PI / 180.0) * (double)0x40000000);
    psuInsData->sCXZ_MSW     = ((ulTempLatLon >> 16) & 0x0000ffff);
    psuInsData->uCXZ_LSW     = ( ulTempLatLon        & 0x0000ffff);
    ulTempLatLon = (uint32_t)(psuBluemaxXls->fACLOND / 180.0 * (double)0x7fffffff);
    psuInsData->sLon_MSW     = ((ulTempLatLon >> 16) & 0x0000ffff);
    psuInsData->uLon_LSW     = ( ulTempLatLon        & 0x0000ffff);
    psuInsData->sAlt         = (int16_t)(psuBluemaxXls->fACAGLF / 4.0);
    //psuInsData->sSteeringError
    //psuInsData->sTiltX
    //psuInsData->sTiltY
    //psuInsData->sJustInCase[4]
    }



// ============================================================================
// 1553 write routines
// ============================================================================

void WriteMsg1553Init(SuWriteMsg1553 * psuWriteMsg1553, uint16_t uChID)
    {
    // Setup the Ch 10 header
    iHeaderInit(&(psuWriteMsg1553->suCh10Header), uChID, I106CH10_DTYPE_1553_FMT_1, I106CH10_PFLAGS_CHKSUM_32 | I106CH10_PFLAGS_TIMEFMT_IRIG106, 0);
    psuWriteMsg1553->suCh10Header.ubyHdrVer = 3;
    psuWriteMsg1553->suCh10Header.ulDataLen = 4;

    // Setup a buffer with enough memory to handle CSDW for now
    psuWriteMsg1553->uBuffLen = 4;
    psuWriteMsg1553->suCh10Header.ulDataLen = 4;
    psuWriteMsg1553->pchDataBuff = (unsigned char *)malloc(psuWriteMsg1553->uBuffLen);
    psuWriteMsg1553->psu1553CSDW = (Su1553F1_ChanSpec *)psuWriteMsg1553->pchDataBuff;

    // Init CSDW
    memset(psuWriteMsg1553->psu1553CSDW, 0, 4);
    psuWriteMsg1553->psu1553CSDW->uTTB    = 0;
    psuWriteMsg1553->psu1553CSDW->uMsgCnt = 0;
    } // WriteMsg1553Init()


// ----------------------------------------------------------------------------

// Append a 1553 message to the end of a 1553 packet.
// No status response is indicated by Status Word = -1
// The message length value in the IPH needs to be correct, even for Mode Codes.

void WriteMsg1553Append(SuWriteMsg1553 * psuWriteMsg1553, Su1553F1_Header * psu1553IPH, 
        int32_t iCmdWord1, int32_t iStatWord1, int32_t iCmdWord2, int32_t iStatWord2,
        uint16_t auData[])
    {
    unsigned        uCurrBufferOffset;
    unsigned        uDataBytes;
    SuCmdWordU      suCmdWord1;
    SuCmdWordU      suCmdWord2;
    SuStatWordU     suStatWord1;
    SuStatWordU     suStatWord2;

    // If this is the first message then the packet RTC is the first message RTC
    if (psuWriteMsg1553->psu1553CSDW->uMsgCnt == 0)
        {
        // This assumes intra-packet time is in RTC format
        memcpy(psuWriteMsg1553->suCh10Header.aubyRefTime, psu1553IPH->aubyIntPktTime, 6);
        }

    suCmdWord1.uValue  = (uint16_t)(iCmdWord1  & 0x0000ffff);
    suCmdWord2.uValue  = (uint16_t)(iCmdWord2  & 0x0000ffff);
    suStatWord1.uValue = (uint16_t)(iStatWord1 & 0x0000ffff);
    suStatWord2.uValue = (uint16_t)(iStatWord2 & 0x0000ffff);

    uCurrBufferOffset = psuWriteMsg1553->suCh10Header.ulDataLen;
    psuWriteMsg1553->psu1553CSDW->uMsgCnt++;

    // Expand the 1553 packet buffer if necessary
    psuWriteMsg1553->suCh10Header.ulDataLen += sizeof(Su1553F1_Header) + psu1553IPH->uMsgLen;
    if (psuWriteMsg1553->suCh10Header.ulDataLen > psuWriteMsg1553->uBuffLen)
        {
        psuWriteMsg1553->uBuffLen += 1000;
        psuWriteMsg1553->pchDataBuff = (unsigned char *)realloc(psuWriteMsg1553->pchDataBuff, psuWriteMsg1553->uBuffLen);
        psuWriteMsg1553->psu1553CSDW = (Su1553F1_ChanSpec *)psuWriteMsg1553->pchDataBuff;
        }
    
    // Build one of the various packet layouts

    // Regular message
    if (psu1553IPH->bRT2RT == 0)
        // Transmit command but no status response, so no data either
        if ((suCmdWord1.suStruct.bTR == 1) && (iStatWord1 < 0))
            {
            // Intrapacket header
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, psu1553IPH, sizeof(Su1553F1_Header));
            uCurrBufferOffset += sizeof(Su1553F1_Header);

            // Command Word 1
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord1.uValue, 2);
            uCurrBufferOffset += 2;
            } // end if no transmit status or data

        // Receive command but no status response
        else if ((suCmdWord1.suStruct.bTR == 0) && (iStatWord1 < 0))
            {
            // Intrapacket header
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, psu1553IPH, sizeof(Su1553F1_Header));
            uCurrBufferOffset += sizeof(Su1553F1_Header);

            // Command Word 1
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord1.uValue, 2);
            uCurrBufferOffset += 2;

            // Data
            uDataBytes = psu1553IPH->uMsgLen - 2;
            if (uDataBytes > 0)
                {
                memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, auData, uDataBytes);
                uCurrBufferOffset += uDataBytes;
                }
            } // end if no receive status

        // Full message
        else
            {
            // Intrapacket header
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, psu1553IPH, sizeof(Su1553F1_Header));
            uCurrBufferOffset += sizeof(Su1553F1_Header);

            // Command Word 1
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord1.uValue, 2);
            uCurrBufferOffset += 2;

            // Transmit command
            if (suCmdWord1.suStruct.bTR == 1)
                {
                // Status Word 1
                memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suStatWord1.uValue, 2);
                uCurrBufferOffset += 2;

                // Data
                uDataBytes = psu1553IPH->uMsgLen - 4;
                if (uDataBytes > 0)
                    {
                    memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, auData, uDataBytes);
                    uCurrBufferOffset += uDataBytes;
                    }
                }

            // Receive command
            else
                {
                // Data
                uDataBytes = psu1553IPH->uMsgLen - 4;
                if (uDataBytes > 0)
                    {
                    memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, auData, uDataBytes);
                    uCurrBufferOffset += uDataBytes;
                    }

                // Status Word 1
                memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suStatWord1.uValue, 2);
                uCurrBufferOffset += 2;
                }

            } // end if full message

    // RT to RT
    else
        // No transmit status response so only command words
        if (iStatWord2 < 0)
            {
            // Intrapacket header
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, psu1553IPH, sizeof(Su1553F1_Header));
            uCurrBufferOffset += sizeof(Su1553F1_Header);

            // Command Word 1
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord1.uValue, 2);
            uCurrBufferOffset += 2;

            // Command Word 2
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord2.uValue, 2);
            uCurrBufferOffset += 2;
            } // end if RT to RT, no transmit status or data

        // No receive status word so commands words, transmit status, and data
        else if ((iStatWord2 >= 0) && (iStatWord1 < 0))
            {
            // Intrapacket header
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, psu1553IPH, sizeof(Su1553F1_Header));
            uCurrBufferOffset += sizeof(Su1553F1_Header);

            // Command Word 1
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord1.uValue, 2);
            uCurrBufferOffset += 2;

            // Command Word 2
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord2.uValue, 2);
            uCurrBufferOffset += 2;

            // Status Word 2
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suStatWord2.uValue, 2);
            uCurrBufferOffset += 2;

            // Data
            uDataBytes = psu1553IPH->uMsgLen - 6;
            if (uDataBytes > 0)
                {
                memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, auData, uDataBytes);
                uCurrBufferOffset += uDataBytes;
                }
            } // end if RT to RT, no receive status

        // Full RT to RT message
        else
            {
            // Intrapacket header
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, psu1553IPH, sizeof(Su1553F1_Header));
            uCurrBufferOffset += sizeof(Su1553F1_Header);

            // Command Word 1
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord1.uValue, 2);
            uCurrBufferOffset += 2;

            // Command Word 2
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suCmdWord2.uValue, 2);
            uCurrBufferOffset += 2;

            // Status Word 2
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suStatWord2.uValue, 2);
            uCurrBufferOffset += 2;

            // Data
            uDataBytes = psu1553IPH->uMsgLen - 8;
            if (uDataBytes > 0)
                {
                memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, auData, uDataBytes);
                uCurrBufferOffset += uDataBytes;
                }

            // Status Word 1
            memcpy(psuWriteMsg1553->pchDataBuff + uCurrBufferOffset, &suStatWord1.uValue, 2);
            uCurrBufferOffset += 2;
            } // end if full RT to RT

    } // end WriteMsg1553Append()


// ----------------------------------------------------------------------------

void WriteMsg1553Commit(int iI106Handle, SuWriteMsg1553 * psuWriteMsg1553)
    {
    uint32_t    uDataBuffLen;

    // Make sure the data buffer is big enough to hold the filler and checksum
    int     iChecksumType = psuWriteMsg1553->suCh10Header.ubyPacketFlags & I106CH10_PFLAGS_CHKSUM_MASK;
    uDataBuffLen = uCalcDataBuffReqSize(psuWriteMsg1553->suCh10Header.ulDataLen, iChecksumType);

    if (uDataBuffLen > psuWriteMsg1553->uBuffLen)
        {
        psuWriteMsg1553->uBuffLen += 1000;
        psuWriteMsg1553->pchDataBuff = (unsigned char *)realloc(psuWriteMsg1553->pchDataBuff, psuWriteMsg1553->uBuffLen);
        psuWriteMsg1553->psu1553CSDW = (Su1553F1_ChanSpec *)psuWriteMsg1553->pchDataBuff;
        }

    // Put a checksum on the end of the packet
    uAddDataFillerChecksum(&(psuWriteMsg1553->suCh10Header), psuWriteMsg1553->pchDataBuff);

    // Update the packet length and data length fields
    psuWriteMsg1553->suCh10Header.ulPacketLen = iGetHeaderLen(&(psuWriteMsg1553->suCh10Header)) + uDataBuffLen;
//    psuWriteMsg1553->suCh10Header.ulDataLen = psuWriteMsg1553->uDataLen;
    psuWriteMsg1553->suCh10Header.uChecksum = uCalcHeaderChecksum(&(psuWriteMsg1553->suCh10Header));

    // Write it
    enI106Ch10WriteMsg(iI106Handle, &(psuWriteMsg1553->suCh10Header), psuWriteMsg1553->pchDataBuff);

    // Reset the buffer
    psuWriteMsg1553->suCh10Header.ubySeqNum++;
    psuWriteMsg1553->suCh10Header.ulDataLen = 4;
    psuWriteMsg1553->psu1553CSDW->uMsgCnt = 0;

    return;
    } // WriteMsg1553Commit()


// ============================================================================
// Time packet write routines
// ============================================================================

void WritePktTimeF1Init(SuWritePktTimeF1 * psuWritePktTimeF1, uint16_t uChID)
    {
    // Setup the Ch 10 header
    iHeaderInit(&(psuWritePktTimeF1->suCh10Header), uChID, I106CH10_DTYPE_IRIG_TIME, I106CH10_PFLAGS_CHKSUM_32 | I106CH10_PFLAGS_TIMEFMT_IRIG106, 0);
    psuWritePktTimeF1->suCh10Header.ubyHdrVer = 3;
    psuWritePktTimeF1->suCh10Header.ulDataLen = sizeof(SuTimeF1_ChanSpec) + sizeof(SuTime_MsgDmyFmt);
    }


// ----------------------------------------------------------------------------

// Return the low BCD from an integer and then divide by 10 shifting the BCD
// value to the right one digit.

unsigned uLowBcdDigit(int * piValToConvert)
    {
    unsigned    uBcdDigit;

    uBcdDigit       = *piValToConvert % 10;
    *piValToConvert = *piValToConvert / 10;

    return uBcdDigit;
    }

// ----------------------------------------------------------------------------

void WritePktTimeF1(int iI106Handle, SuWritePktTimeF1 * psuWritePktTimeF1, double fCurrSimClockTime)
    {
    struct tm         * psuCurrSimClockTime;
    int                 iValToConvert;

    // Zero out the data packet
    memset(&(psuWritePktTimeF1->suTimePktBuffer), 0, sizeof(psuWritePktTimeF1->suTimePktBuffer));

    // Setup the CSDW
    psuWritePktTimeF1->suTimePktBuffer.suTimeF1CSDW.uTimeSrc = I106_TIMESRC_INTERNAL;
    psuWritePktTimeF1->suTimePktBuffer.suTimeF1CSDW.uTimeFmt = I106_TIMEFMT_INT_RTC;
    psuWritePktTimeF1->suTimePktBuffer.suTimeF1CSDW.uDateFmt = 1; // DMY

    // Start making the time packet
    time_t  iCurrSimClockTime = (time_t)fCurrSimClockTime;
    psuCurrSimClockTime = gmtime(&iCurrSimClockTime);

    // Year
    iValToConvert = psuCurrSimClockTime->tm_year + 1900;
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uYn  = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uTYn = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uHYn = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uOYn = uLowBcdDigit(&iValToConvert);

    // Month
    iValToConvert = psuCurrSimClockTime->tm_mon + 1;
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uOn  = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uTOn = uLowBcdDigit(&iValToConvert);

    // Day
    iValToConvert = psuCurrSimClockTime->tm_mday;
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uDn  = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uTDn = uLowBcdDigit(&iValToConvert);

    // Hour
    iValToConvert = psuCurrSimClockTime->tm_hour;
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uHn  = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uTHn = uLowBcdDigit(&iValToConvert);

    // Minute
    iValToConvert = psuCurrSimClockTime->tm_min;
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uMn  = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uTMn = uLowBcdDigit(&iValToConvert);

    // Second
    iValToConvert = psuCurrSimClockTime->tm_sec;
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uSn  = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uTSn = uLowBcdDigit(&iValToConvert);

    // Milliseconds
    iValToConvert = (int)((fCurrSimClockTime - (int)fCurrSimClockTime) * 99.9);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uTmn = uLowBcdDigit(&iValToConvert);
    psuWritePktTimeF1->suTimePktBuffer.suTimeDataBuff.uHmn = uLowBcdDigit(&iValToConvert);

    // Make the packet header
//    iHeaderInit(&suI106Hdr, 1, I106CH10_DTYPE_IRIG_TIME, I106CH10_PFLAGS_CHKSUM_NONE, 0);
//    suI106Hdr.ubyHdrVer = 3;
//    suI106Hdr.ulDataLen = sizeof(SuTimeF1_ChanSpec) + sizeof(SuTime_MsgDmyFmt);
    SimClockToRel(iI106Handle, fCurrSimClockTime, psuWritePktTimeF1->suCh10Header.aubyRefTime);
    uAddDataFillerChecksum(&(psuWritePktTimeF1->suCh10Header), (unsigned char *)&(psuWritePktTimeF1->suTimePktBuffer));
    psuWritePktTimeF1->suCh10Header.uChecksum = uCalcHeaderChecksum(&(psuWritePktTimeF1->suCh10Header));


    enI106Ch10WriteMsg(iI106Handle, &(psuWritePktTimeF1->suCh10Header), &(psuWritePktTimeF1->suTimePktBuffer));
    psuWritePktTimeF1->suCh10Header.ubySeqNum++;

    return;
    } // end WriteIrigTimePacket()


// ============================================================================
// TMATS write routines
// ============================================================================

void WriteTmats(int iI106Handle, double fCurrSimClockTime)
    {
    SuI106Ch10Header    suI106Hdr;
    std::stringstream   ssTMATS;
    uint8_t           * pchDataBuff;
    uint32_t            ulDataBuffSize;
    SuTmats_ChanSpec  * psuTmats_ChanSpec;

    // Make a time string for the TMATS in the format 08-19-2014-17-33-59
    time_t        iCurrSimClockTime;
    char          szCurrSimClockTime[100];
    struct tm   * psuCurrSimClockTime;
    iCurrSimClockTime = (time_t)fCurrSimClockTime;
    psuCurrSimClockTime = gmtime(&iCurrSimClockTime);
    strftime(szCurrSimClockTime, sizeof(szCurrSimClockTime), "%m-%d-%Y-%H-%M-%S", psuCurrSimClockTime);

    ssTMATS.clear();
    ssTMATS <<
        "G\\PN:A10 SIM;\n"
        "G\\106:07;\n"
        "G\\DSI\\N:1;\n"
        "G\\DSI-1:DATASOURCE;\n"
        "G\\DST-1:STO;\n"
        "R-1\\R1:Bluemax to Ch 10;\n"
        "R-1\\RI1:irig106.org;\n"
        "R-1\\RI2:BMtoCh10;\n"
        "R-1\\RI3:Y;\n";
    ssTMATS <<
        "R-1\\RI4:" << szCurrSimClockTime << ";\n";
    ssTMATS <<
        "R-1\\ID:DATASOURCE;\n"
        "R-1\\N:17;\n"
        "\n"
        "R-1\\TK1-1:1;\n"
        "R-1\\CHE-1:T;\n"
        "R-1\\DSI-1:TimeInChan1;\n"
        "R-1\\CDT-1:TIMIN;\n"
        "R-1\\IFMT-1:I;\n"
        "\n"
        "R-1\\TK1-2:2;\n"
        "R-1\\CHE-2:T;\n"
        "R-1\\DSI-2:VideoInChan1;\n"
        "R-1\\CDT-2:VIDIN;\n"
        "M-1\\ID:VideoInChan1;\n"
        "M-1\\BSG1:PCM;\n"
        "M-1\\BB\\DLN:VideoInChan1;\n"
        "P-1\\DLN:VideoInChan1;\n"
        "P-1\\D2:4000000;\n"
        "\n"
        "R-1\\TK1-3:3;\n"
        "R-1\\CHE-3:T;\n"
        "R-1\\DSI-3:VideoInChan2;\n"
        "R-1\\CDT-3:VIDIN;\n"
        "M-2\\ID:VideoInChan2;\n"
        "M-2\\BSG1:PCM;\n"
        "M-2\\BB\\DLN:VideoInChan2;\n"
        "P-2\\DLN:VideoInChan2;\n"
        "P-2\\D2:4000000;\n"
        "\n"
        "R-1\\TK1-4:4;\n"
        "R-1\\CHE-4:F;\n"
        "R-1\\DSI-4:VideoInChan3;\n"
        "R-1\\CDT-4:VIDIN;\n"
        "M-3\\ID:VideoInChan3;\n"
        "M-3\\BSG1:PCM;\n"
        "M-3\\BB\\DLN:VideoInChan3;\n"
        "P-3\\DLN:VideoInChan3;\n"
        "P-3\\D2:4000000;\n"
        "\n"
        "R-1\\TK1-5:5;\n"
        "R-1\\CHE-5:F;\n"
        "R-1\\DSI-5:VideoInChan4;\n"
        "R-1\\CDT-5:VIDIN;\n"
        "M-4\\ID:VideoInChan4;\n"
        "M-4\\BSG1:PCM;\n"
        "M-4\\BB\\DLN:VideoInChan4;\n"
        "P-4\\DLN:VideoInChan4;\n"
        "P-4\\D2:4000000;\n"
        "\n"
        "R-1\\TK1-6:6;\n"
        "R-1\\CHE-6:F;\n"
        "R-1\\DSI-6:VideoInChan5;\n"
        "R-1\\CDT-6:VIDIN;\n"
        "M-5\\ID:VideoInChan5;\n"
        "M-5\\BSG1:PCM;\n"
        "M-5\\BB\\DLN:VideoInChan5;\n"
        "P-5\\DLN:VideoInChan5;\n"
        "P-5\\D2:0;\n"
        "\n"
        "R-1\\TK1-7:7;\n"
        "R-1\\CHE-7:F;\n"
        "R-1\\DSI-7:VideoInChan6;\n"
        "R-1\\CDT-7:VIDIN;\n"
        "M-6\\ID:VideoInChan6;\n"
        "M-6\\BSG1:PCM;\n"
        "M-6\\BB\\DLN:VideoInChan6;\n"
        "P-6\\DLN:VideoInChan6;\n"
        "P-6\\D2:0;\n"
        "\n"
        "R-1\\TK1-8:8;\n"
        "R-1\\CHE-8:F;\n"
        "R-1\\DSI-8:VideoInChan7;\n"
        "R-1\\CDT-8:VIDIN;\n"
        "M-7\\ID:VideoInChan7;\n"
        "M-7\\BSG1:PCM;\n"
        "M-7\\BB\\DLN:VideoInChan7;\n"
        "P-7\\DLN:VideoInChan7;\n"
        "P-7\\D2:0;\n"
        "\n"
        "R-1\\TK1-9:9;\n"
        "R-1\\CHE-9:F;\n"
        "R-1\\DSI-9:VideoInChan8;\n"
        "R-1\\CDT-9:VIDIN;\n"
        "M-8\\ID:VideoInChan8;\n"
        "M-8\\BSG1:PCM;\n"
        "M-8\\BB\\DLN:VideoInChan8;\n"
        "P-8\\DLN:VideoInChan8;\n"
        "P-8\\D2:0;\n"
        "\n"
        "R-1\\TK1-10:10;\n"
        "R-1\\CHE-10:F;\n"
        "R-1\\DSI-10:1553InChan1;\n"
        "R-1\\CDT-10:1553IN;\n"
        "M-9\\ID:1553InChan1;\n"
        "M-9\\BSG1:PCM;\n"
        "M-9\\BB\\DLN:1553InChan1;\n"
        "B-1\\DLN:1553InChan1;\n"
        "B-1\\NBS\\N:1;\n"
        "\n"
        "R-1\\TK1-11:11;\n"
        "R-1\\CHE-11:T;\n"
        "R-1\\DSI-11:1553InChan2;\n"
        "R-1\\CDT-11:1553IN;\n"
        "M-10\\ID:1553InChan2;\n"
        "M-10\\BSG1:PCM;\n"
        "M-10\\BB\\DLN:1553InChan2;\n"
        "B-2\\DLN:1553InChan2;\n"
        "B-2\\NBS\\N:1;\n"
        "\n"
        "R-1\\TK1-12:12;\n"
        "R-1\\CHE-12:F;\n"
        "R-1\\DSI-12:1553InChan3;\n"
        "R-1\\CDT-12:1553IN;\n"
        "M-11\\ID:1553InChan3;\n"
        "M-11\\BSG1:PCM;\n"
        "M-11\\BB\\DLN:1553InChan3;\n"
        "B-3\\DLN:1553InChan3;\n"
        "B-3\\NBS\\N:1;\n"
        "\n"
        "R-1\\TK1-13:13;\n"
        "R-1\\CHE-13:F;\n"
        "R-1\\DSI-13:1553InChan4;\n"
        "R-1\\CDT-13:1553IN;\n"
        "M-12\\ID:1553InChan4;\n"
        "M-12\\BSG1:PCM;\n"
        "M-12\\BB\\DLN:1553InChan4;\n"
        "B-4\\DLN:1553InChan4;\n"
        "B-4\\NBS\\N:1;\n"
        "\n"
        "R-1\\TK1-14:14;\n"
        "R-1\\CHE-14:F;\n"
        "R-1\\DSI-14:1553InChan5;\n"
        "R-1\\CDT-14:1553IN;\n"
        "M-13\\ID:1553InChan5;\n"
        "M-13\\BSG1:PCM;\n"
        "M-13\\BB\\DLN:1553InChan5;\n"
        "B-5\\DLN:1553InChan5;\n"
        "B-5\\NBS\\N:1;\n"
        "\n"
        "R-1\\TK1-15:15;\n"
        "R-1\\CHE-15:F;\n"
        "R-1\\DSI-15:1553InChan6;\n"
        "R-1\\CDT-15:1553IN;\n"
        "M-14\\ID:1553InChan6;\n"
        "M-14\\BSG1:PCM;\n"
        "M-14\\BB\\DLN:1553InChan6;\n"
        "B-6\\DLN:1553InChan6;\n"
        "B-6\\NBS\\N:1;\n"
        "\n"
        "R-1\\TK1-16:16;\n"
        "R-1\\CHE-16:F;\n"
        "R-1\\DSI-16:1553InChan7;\n"
        "R-1\\CDT-16:1553IN;\n"
        "M-15\\ID:1553InChan7;\n"
        "M-15\\BSG1:PCM;\n"
        "M-15\\BB\\DLN:1553InChan7;\n"
        "B-7\\DLN:1553InChan7;\n"
        "B-7\\NBS\\N:1;\n"
        "\n"
        "R-1\\TK1-17:17;\n"
        "R-1\\CHE-17:F;\n"
        "R-1\\DSI-17:1553InChan8;\n"
        "R-1\\CDT-17:1553IN;\n"
        "M-16\\ID:1553InChan8;\n"
        "M-16\\BSG1:PCM;\n"
        "M-16\\BB\\DLN:1553InChan8;\n"
        "B-8\\DLN:1553InChan8;\n"
        "B-8\\NBS\\N:1;\n";

    // Form the TMATS header
    iHeaderInit(&suI106Hdr, 0, I106CH10_DTYPE_TMATS, I106CH10_PFLAGS_CHKSUM_32 | I106CH10_PFLAGS_TIMEFMT_IRIG106, 0);
    suI106Hdr.ulDataLen = sizeof(SuTmats_ChanSpec) + ssTMATS.str().length();
    suI106Hdr.ubyHdrVer = 3;
    SimClockToRel(iI106Handle, fCurrSimClockTime, suI106Hdr.aubyRefTime);
//    memset(suI106Hdr.aubyRefTime, 0, 6);

    // Setup the TMATS data portion
    ulDataBuffSize = uCalcDataBuffReqSize(suI106Hdr.ulDataLen, I106CH10_PFLAGS_CHKSUM_32);
    pchDataBuff = (uint8_t *)malloc(ulDataBuffSize);
    memset(pchDataBuff, 0, ulDataBuffSize);
    psuTmats_ChanSpec = (SuTmats_ChanSpec *)pchDataBuff;
    psuTmats_ChanSpec->iCh10Ver = 7;
    memcpy(&pchDataBuff[4], ssTMATS.str().c_str(), ssTMATS.str().length());
    uAddDataFillerChecksum(&suI106Hdr, pchDataBuff);
    suI106Hdr.uChecksum = uCalcHeaderChecksum(&suI106Hdr);

    enI106Ch10WriteMsg(iI106Handle, &suI106Hdr, pchDataBuff);

    free(pchDataBuff);
    }


// ----------------------------------------------------------------------------

void vUsage(void)
    {
    printf("\nBMtoCh10  " __DATE__ " " __TIME__ "\n");
    printf("Convert a Bluemax XLS simulation file to a Ch 10 1553 nav message file\n");
    printf("Usage: BMtoCh10 <input file> <output file> [flags]\n");
    printf("   <filename> Input/output file names        \n");
    printf("   -t         Data start time m-d-y-h-m-s    \n");
    }
